package ru.mercedesdoctorai

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.InputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val spp = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private var socket: BluetoothSocket? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null
    private val rows = mutableListOf<String>()
    private val values = linkedMapOf<String, String>()
    private lateinit var status: TextView
    private lateinit var data: TextView
    private lateinit var log: TextView
    private lateinit var connectBtn: Button
    private var polling = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 20)
        }
        status = TextView(this).apply { textSize = 18f; text = "Mercedes E200 W212 • M274\nАдаптер не подключён" }
        data = TextView(this).apply { textSize = 16f; text = "Нет данных" }
        log = TextView(this).apply { textSize = 13f }
        connectBtn = Button(this).apply { text = "Подключить Bluetooth ELM327"; setOnClickListener { connect() } }
        val scanBtn = Button(this).apply { text = "Считать ошибки двигателя"; setOnClickListener { readCodes() } }
        val recordBtn = Button(this).apply { text = "Запись поездки: старт / стоп"; setOnClickListener { toggleRecord() } }
        val exportBtn = Button(this).apply { text = "Поделиться отчётом с ChatGPT"; setOnClickListener { shareReport() } }
        layout.addView(status); layout.addView(connectBtn); layout.addView(data)
        layout.addView(scanBtn); layout.addView(recordBtn); layout.addView(exportBtn); layout.addView(log)
        setContentView(ScrollView(this).apply { addView(layout) })
        requestBtPermission()
    }

    private fun requestBtPermission() {
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN), 22)
        }
    }

    private fun connect() {
        try {
            val adapter = BluetoothAdapter.getDefaultAdapter()
            if (adapter == null || !adapter.isEnabled) { toast("Включи Bluetooth"); return }
            val devices = adapter.bondedDevices.toList()
            if (devices.isEmpty()) { toast("Сначала сопряги ELM327 в настройках Bluetooth Android"); return }
            val names = devices.map { "${it.name ?: "Bluetooth"} • ${it.address}" }.toTypedArray()
            android.app.AlertDialog.Builder(this).setTitle("Выбери ELM327")
                .setItems(names) { _, which -> connectDevice(devices[which]) }.show()
        } catch (_: SecurityException) { toast("Разреши доступ к устройствам поблизости") }
    }

    private fun connectDevice(device: BluetoothDevice) {
        status.text = "Подключение к ${device.name}…"
        thread {
            try {
                val s = device.createRfcommSocketToServiceRecord(spp)
                s.connect()
                socket = s; input = s.inputStream; output = s.outputStream
                val init = listOf("ATZ", "ATE0", "ATL0", "ATS0", "ATH0", "ATSP0")
                init.forEach { command(it) }
                runOnUiThread {
                    status.text = "Подключено: ${device.name}\nELM327 • профиль OBD-II"
                    connectBtn.text = "Переподключить"
                }
                startPolling()
            } catch (e: Exception) {
                runOnUiThread { status.text = "Ошибка подключения: ${e.message}" }
            }
        }
    }

    @Synchronized private fun command(cmd: String): String {
        val out = output ?: return ""
        val inp = input ?: return ""
        out.write((cmd + "\r").toByteArray())
        out.flush()
        val result = StringBuilder()
        val deadline = System.currentTimeMillis() + 1800
        while (System.currentTimeMillis() < deadline) {
            if (inp.available() > 0) {
                val b = inp.read()
                if (b == 62) break
                if (b >= 0) result.append(b.toChar())
            } else Thread.sleep(20)
        }
        return result.toString().replace("\r", " ").replace("\n", " ").trim()
    }

    private fun pid(cmd: String, label: String, decode: (String) -> String) {
        val raw = command(cmd).replace(" ", "")
        val marker = "41" + cmd.takeLast(2).uppercase(Locale.US)
        val idx = raw.indexOf(marker)
        if (idx >= 0 && raw.length >= idx + 6) {
            val a = raw.substring(idx + 4, idx + 6).toIntOrNull(16)
            val b = raw.substring(idx + 6, idx + 8).toIntOrNull(16)
            if (a != null) values[label] = decode(if (b != null) "%02X%02X".format(a,b) else "%02X".format(a))
        }
    }

    private fun startPolling() {
        if (polling) return
        polling = true
        thread {
            while (polling && socket?.isConnected == true) {
                try {
                    pid("010C", "Обороты", { h -> ((h.toInt(16) / 4.0).toInt()).toString() + " об/мин" })
                    pid("0105", "ОЖ", { h -> (h.take(2).toInt(16)-40).toString() + " °C" })
                    pid("010F", "Впускной воздух", { h -> (h.take(2).toInt(16)-40).toString() + " °C" })
                    pid("010B", "MAP", { h -> h.take(2).toInt(16).toString() + " кПа" })
                    pid("0111", "Дроссель", { h -> "%.1f%%".format(h.take(2).toInt(16)*100.0/255.0) })
                    pid("0106", "STFT B1", { h -> "%.1f%%".format((h.take(2).toInt(16)-128)*100.0/128.0) })
                    pid("0107", "LTFT B1", { h -> "%.1f%%".format((h.take(2).toInt(16)-128)*100.0/128.0) })
                    pid("0142", "Напряжение ECU", { h -> "%.2f В".format(h.toInt(16)/1000.0) })
                    val snapshot = values.toMap()
                    if (recording) rows.add("${System.currentTimeMillis()}," + snapshot.values.joinToString(","))
                    runOnUiThread { data.text = snapshot.entries.joinToString("\n") { "${it.key}: ${it.value}" } }
                    Thread.sleep(1000)
                } catch (e: Exception) {
                    runOnUiThread { status.text = "Связь прервана: ${e.message}" }
                    polling = false
                }
            }
        }
    }

    private fun readCodes() {
        thread {
            val codes = command("03")
            runOnUiThread { log.text = "Ответ ЭБУ (Mode 03): $codes\nЕсли ответ NO DATA, это не подтверждает отсутствие фирменных ошибок Mercedes." }
        }
    }

    private var recording = false
    private fun toggleRecord() {
        recording = !recording
        if (recording) { rows.clear(); rows.add("timestamp_ms," + values.keys.joinToString(",")); toast("Запись начата") }
        else toast("Запись остановлена • ${rows.size} строк")
    }

    private fun shareReport() {
        val report = buildString {
            appendLine("Mercedes-Benz E200 W212 2014, двигатель M274")
            appendLine("Адаптер: Bluetooth ELM327; данные стандартного OBD-II")
            appendLine("Дата: ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())}")
            appendLine("Текущие параметры:")
            values.forEach { (k,v) -> appendLine("$k: $v") }
            appendLine("\nЗапись поездки: ${rows.size} строк")
            appendLine("Важно: это универсальные OBD-II данные, не полный Xentry-скан.")
            appendLine("Проанализируй тренды, качество данных и безопасные следующие проверки. Не утверждай неисправность без подтверждения.")
            appendLine("\nCSV:\n" + rows.takeLast(1500).joinToString("\n"))
        }
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"; putExtra(Intent.EXTRA_SUBJECT, "Mercedes Doctor — отчёт M274")
            putExtra(Intent.EXTRA_TEXT, report)
        }
        startActivity(Intent.createChooser(intent, "Передать отчёт в ChatGPT или сохранить"))
    }

    override fun onDestroy() {
        polling = false
        try { socket?.close() } catch (_: Exception) {}
        super.onDestroy()
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
